function showMessage() {
  alert("Thank you for your interest in Longevity Lifestyle Resorts! More details coming soon.");
}